n = [1,2,3,4,5,9,13]
a = []
for i in list(n):
    if i % 1 ==0 and i % i ==0:
         a.append(i**2)
print(a)

